package com.example.bmicalculator

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity()
{

    lateinit var weightEditText: EditText
    lateinit var heightEditText: EditText
    lateinit var calculateButton: Button
    lateinit var resultTextView: TextView

    override fun onCreate(savedInstanceState: Bundle?)
    {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        weightEditText = findViewById(R.id.editWeight)
        heightEditText = findViewById(R.id.editHeight)
        calculateButton = findViewById(R.id.btnCalculate)
        resultTextView = findViewById(R.id.txtResult)

        calculateButton.setOnClickListener {

            val weightStr = weightEditText.text.toString()
            val heightStr = heightEditText.text.toString()

            if(weightStr.isEmpty() || heightStr.isEmpty())
            {
                Toast.makeText(this, "Please enter weight and height", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val weight = weightStr.toDouble()
            val height = heightStr.toDouble()

            val bmi = weight / (height * height)

            val category = when {
                bmi < 18.5 -> "Underweight"
                bmi < 24.9 -> "Normal weight"
                bmi < 29.9 -> "Overweight"
                else -> "Obese"
            }

            resultTextView.text = "BMI = %.2f\nCategory: %s".format(bmi, category)
        }
    }
}